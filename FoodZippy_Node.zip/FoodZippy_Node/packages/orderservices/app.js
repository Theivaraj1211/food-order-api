// const express = require('express');
// const app = express();
// const http = require('http');
// const server = http.createServer(app);
// const mongoose = require('mongoose');
// //const db = require('../common/connection');
// // Import the router
// const router = require('./router/orderrouter');
// // Import WebSocket server setup
// require('./webscoket/websocket_sever');
// app.use(express.json());

// // MongoDB connection
// mongoose.connect(`mongodb+srv://development:AwDXlClV8QtJG18h@cluster0.ms7zlpo.mongodb.net/test?retryWrites=true&w=majority`, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
//     serverSelectionTimeoutMS: 30000, // Example: Set server selection timeout to 30 seconds
//     socketTimeoutMS: 45000
// });

// const db = mongoose.connection;

// db.on('error', console.error.bind(console, 'MongoDB connection error:'));
// db.once('open', () => {
//     console.log('Connected to MongoDB');
// });
// // Use the router for your API routes
// app.use('/api', router);

// server.listen(3001, () => {
//     console.log('Server is running on port 3001');
// });
const express = require('express');
const app = express();
const router = require('./router/orderrouter');
require('./webscoket/websocket_sever');
const mongoose = require('mongoose');

app.use(express.json());

mongoose.connect(
    `mongodb+srv://development:AwDXlClV8QtJG18h@cluster0.ms7zlpo.mongodb.net/test?retryWrites=true&w=majority`,
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }, 6000000
).then(() => {
    console.log('Connected to MongoDB');
}).catch((error) => {
    console.error('MongoDB connection error:', error);
});

app.use('/api', router);

const port = 3001;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

