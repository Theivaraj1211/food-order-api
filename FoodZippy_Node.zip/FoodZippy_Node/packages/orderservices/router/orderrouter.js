const express = require("express");
const Router = express.Router();
const {
  createOrder,
  updateOrderFromAdmin,
  getOrdersByUser,
  getAllorder,
  getOrderById,
  cancelOrderFromUser,
  cancelOrderByAdmin,
  getOrderByAdmin,
  overallReports,
  customersDetails,
  getCustomerInfo,
  totalSalesReport,
  salesReport,
  mostOrder,
  businessreview,
  customerReport,
  campaignPerReport,
  netSales,
} = require("../controller/ordercontroller"); // Import the controller function
const {
  requireUserAuth,
} = require("../../../packages/userservices/middleware/vaildateUserToken");
const {
  requireAdminAuth,
} = require("../../../packages/userservices/middleware/vaildateAdminToken");

Router.post("/", requireUserAuth, createOrder);
Router.put("/:orderId", requireAdminAuth, updateOrderFromAdmin);
Router.get("/", requireUserAuth, getOrdersByUser);
Router.get("/all/order", getAllorder);//38,39
Router.get("/user/:orderId", getOrderById);
Router.put("/:orderId/user", requireUserAuth, cancelOrderFromUser);
Router.put("/:orderId/admin", requireAdminAuth, cancelOrderByAdmin);
Router.get("/admin/userOrderInformation", requireAdminAuth, getOrderByAdmin);
Router.get("/overall-report/:restaurant_id", overallReports);
Router.get("/admin/customerDetail/:resId", requireAdminAuth, customersDetails);//59
Router.get("/admin/customerDetail/:restaurantid/:userid", getCustomerInfo);//60
Router.get("/customerreport/:id", customerReport)
Router.get("/dashboard/salesreport/:id", requireAdminAuth, salesReport);
Router.get("/dashboard/totalsalesreport/:id", requireAdminAuth, totalSalesReport)//92,97,98
Router.get("/bussinessreview/:id", businessreview);
Router.get("/getcustomerPerReport/:id", campaignPerReport);
Router.get("/report/netsales", requireAdminAuth, netSales)//93
module.exports = Router;
