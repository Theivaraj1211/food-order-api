const WebSocket = require('ws');
const http = require('http');

const server = http.createServer((req, res) => {
    // Handle HTTP requests if needed
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('WebSocket server is running on a separate port.');
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('WebSocket client connected');

    ws.on('message', (message) => {
        console.log(`Received: ${message}`);
    });

    ws.on('close', () => {
        console.log('WebSocket client disconnected');
    });
});
// function broadcastOrder(orderMessage) {
//     if (wss) {
//         wss.clients.forEach((client) => {
//             if (client.readyState === WebSocket.OPEN) {
//                 client.send(orderMessage);
//             }
//         });
//     }
// }


server.listen(8080, () => {
    console.log('WebSocket server is running on port 8080');
});
module.exports = wss;
