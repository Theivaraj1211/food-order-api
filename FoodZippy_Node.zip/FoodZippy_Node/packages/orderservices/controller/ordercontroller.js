const FoodOrder = require("../../common/model/orderSchema");
const WebSocket = require("ws");
const user = require("../../common/model/userSchema")
const Address = require("../../common/model/addressSchema");
const cart = require('../../common/model/addcartitemSchema');
const MenuItem = require("../../common/model/menuSchema");
const delivery = require("../../common/model/deliverypersonSchema");
const Restaurant = require("../../common/model/restaurantSchema");
const wss = require('../webscoket/websocket_sever');
const Joi = require("joi");
const { ObjectId } = require('mongodb');
const mongoose = require("mongoose")
const { v4: uuidv4 } = require("uuid");
const User = require("../../common/model/userSchema");
//let wss;

function setWebSocketServer(websocketServer) {
  wss = websocketServer;
}
// Define a Joi schema for validating the request body
const foodOrderJoiSchema = Joi.object({
  user: Joi.string(),
  cart_id: Joi.string(),
  delivery_id: Joi.string(),
  admin_id: Joi.string(),
  restaurant_id: Joi.string(),
  cash_on_delivery: Joi.boolean(),
  created_at: Joi.date(),
  updated_at: Joi.date(),
  status: Joi.string()
    .valid(
      "pending",
      "accepted",
      "preparing",
      "packing",
      "pickup",
      "on the way",
      "delivered",
      "cancel"
    )
    .default("pending"),
  comment: Joi.string(),
  is_active: Joi.boolean(),
  address_id: Joi.string(),
  payment_id: Joi.string(),
  total_amount: Joi.number(),
  userresponseforcancel: Joi.string().valid(
    "order taking too long",
    "placed order by mistake",
    "item is not available",
    "change by mind",
    "other",
  ),
  reason_for_cancel_byadmin: Joi.string().valid(
    "change in delivery address",
    "seller not able to entertain some request",
    "product is taking too long to be delivered",
    "cash not available for COD",
  ),
  created_by: Joi.string(),
  updated_by: Joi.string(),
  delivery_address_id: Joi.string(),
});
const createOrder = async (req, res) => {
  try {
    // Generate orderId using UUID
    const orderId = uuidv4();

    // Retrieve user_id from the token (assuming it's stored in req.user)
    const userId = req.user.id; // Assuming user ID is available in the token payload

    // Fetch the delivery address ID from the addresses table based on the user_id
    const userAddress = await Address.findOne({
      user: userId,
      is_default: true,
    });
    if (!userAddress) {
      return res
        .status(404)
        .json({ error: "Delivery address not found for the user." });
    }

    // Update the cart with cart_id received in the request body to set _active to false
    const { cart_id } = req.body; // Assuming cart_id is provided in the request body
    if (!cart_id) {
      return res.status(404).json({ error: "Cart not found." });
    }

    // Validate cart_id in the FoodOrder table
    const existingOrderWithCartId = await FoodOrder.findOne({ cart_id });
    if (existingOrderWithCartId) {
      return res
        .status(400)
        .json({ error: "Order with this cart_id already exists." });
    }

    // Fetch the cart details including totalamount
    const cartDetails = await cart.findOne({ _id: cart_id });
    if (!cartDetails) {
      return res.status(404).json({ error: "Cart not found." });
    }
    const restaurantId = cartDetails.restaurant_id;
    const totalAmount = cartDetails.tax_pack_totalamount;

    // Create the order object
    const orderData = {
      ...req.body,
      total_amount: totalAmount, // Assuming 'totalamount' is a field in your FoodOrder model
      restaurant_id: restaurantId,
    };
    const newOrder = new FoodOrder(orderData);

    // Set orderId, user_id obtained from token, and delivery_id obtained from the address table
    newOrder.orderId = orderId;
    newOrder.user = userId;
    newOrder.address_id = userAddress._id;
    newOrder.delivery_id = userAddress._id; // Assuming the address ID is stored in _id field

    // Save the new order
    const savedOrder = await newOrder.save();

    // Update the cart with cart_id received in the request body to set _active to false
    if (cart_id) {
      await cart.findOneAndUpdate({ _id: cart_id }, { is_active: false });
    }

    // // Fetch menu_item_id associated with the cart_id
    // const cartItem = await cart.findOne({ _id: cart_id }, { menu_item_id: 1 });
    // if (!cartItem) {
    //   return res.status(404).json({ error: "Cart item not found." });
    // }
    // const menu_item_id = cartItem.menu_item_id;

    // // Fetch the restaurant_id associated with the menu_item_id
    // const menuItem = await MenuItem.findOne({ _id: menu_item_id });
    // if (!menuItem) {
    //   return res.status(404).json({ error: "Menu item not found." });
    // }

    //const restaurantId = req.body.restaurant_id;

    // Broadcast the order to all connected clients via WebSocket (if available)
    const orderMessage = JSON.stringify(savedOrder);
    if (wss) {
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          console.log(orderMessage, "kooooo");
          client.send(orderMessage);
        }
      });
    }

    // Modify the response to include totalamount and restaurant_id
    res.status(201).json({
      message: "Order created",
      order: savedOrder,
      total_amount: totalAmount,
      restaurant_id: restaurantId,
    });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({ error: "Unable to create order." });
  }
};

// const createOrder = async (req, res) => {
//   try {
//     // Generate orderId using UUID
//     const orderId = uuidv4();

//     // Retrieve user_id from the token (assuming it's stored in req.user)
//     const userId = req.user.id; // Assuming user ID is available in the token payload

//     // Fetch the delivery address ID from the addresses table based on the user_id
//     const userAddress = await Address.findOne({
//       user: userId,
//       is_default: true,
//     });
//     if (!userAddress) {
//       return res
//         .status(404)
//         .json({ error: "Delivery address not found for the user." });
//     }

//     // Update the cart with cart_id received in the request body to set _active to false
//     const { cart_id } = req.body; // Assuming cart_id is provided in the request body
//     if (!cart_id) {
//       return res.status(404).json({ error: "Cart not found." });
//     }

//     // // Validate cart_id in the FoodOrder table
//     // const existingOrderWithCartId = await FoodOrder.findOne({ cart_id });
//     // if (existingOrderWithCartId) {
//     //   return res
//     //     .status(400)
//     //     .json({ error: "Order with this cart_id already exists." });
//     // }

//     // Fetch the cart details including totalamount
//     const cartDetails = await cart.findOne({ _id: cart_id });
//     if (!cartDetails) {
//       return res.status(404).json({ error: "Cart not found." });
//     }

//     const totalAmount = cartDetails.finalAmount;

//     // Create the order object
//     const orderData = {
//       ...req.body,
//       totalamount: totalAmount, // Assuming 'totalamount' is a field in your FoodOrder model
//     };
//     const newOrder = new FoodOrder(orderData);

//     // Set orderId, user_id obtained from token, and delivery_id obtained from the address table
//     newOrder.orderId = orderId;
//     newOrder.user = userId;
//     newOrder.address_id = userAddress._id;
//     newOrder.delivery_id = userAddress._id; // Assuming the address ID is stored in _id field

//     // Save the new order
//     const savedOrder = await newOrder.save();

//     // Update the cart with cart_id received in the request body to set _active to false
//     if (cart_id) {
//       await cart.findOneAndUpdate({ _id: cart_id }, { is_active: false });
//     }

//     // Fetch menu_item_id associated with the cart_id
//     const cartItem = await cart.findOne({ _id: cart_id }, { menu_item_id: 1 });
//     if (!cartItem) {
//       return res.status(404).json({ error: "Cart item not found." });
//     }
//     console.log(cartItem, "678934567");
//     const menu_item_id = cartItem.menu_item_id;
//     console.log(menu_item_id, "8089000");
//     // Fetch the restaurant_id associated with the menu_item_id
//     const menuItem = await MenuItem.findOne({ _id: menu_item_id });
//     if (!menuItem) {
//       return res.status(404).json({ error: "Menu item not found." });
//     }

//     const restaurantId = menuItem.restaurant_id;

//     // Broadcast the order to all connected clients via WebSocket (if available)
//     const orderMessage = JSON.stringify(savedOrder);
//     if (wss) {
//       wss.clients.forEach((client) => {
//         if (client.readyState === WebSocket.OPEN) {
//           console.log(orderMessage, "kooooo");
//           client.send(orderMessage);
//         }
//       });
//     }

//     res.status(201).json({ message: "Order created", order: savedOrder });
//   } catch (error) {
//     console.error("Error creating order:", error);
//     res.status(500).json({ error: "Unable to create order." });
//   }
// };
// const updateOrderFromAdmin = async (req, res) => {
//   try {
//     const adminId = req.user.id; // Assuming admin ID is available in the token payload

//     const orderIdToUpdate = req.params.orderId; // Assuming the order ID is in the request URL parameters

//     const { delivery_id } = req.body; // Extracting delivery_id from the request body

//     // Find the order to update
//     const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

//     if (!orderToUpdate) {
//       return res.status(404).json({ error: "Order not found." });
//     }

//     // Update order status to 'accepted'
//     orderToUpdate.status = "accepted";

//     // Assign delivery_id if provided in the request body
//     if (delivery_id) {
//       orderToUpdate.delivery_id = delivery_id;
//     }

//     // Fetch cart items or menu items related to this order (assuming it's an array of menu item IDs)
//     const cartItems = orderToUpdate.cart_id; // Assuming cart_id holds an array of menu item IDs

//     // Use your logic to fetch preparation time from menu items in the cart array
//     // Assuming you have a function getPreparationTimeById that fetches preparation time based on menu item ID
//     //   const preparationTimes = await Promise.all(
//     //     cartItems.map(async (itemId) => {
//     //       const preparationTime = await getPreparationTimeById(itemId);
//     //       return preparationTime;
//     //     })
//     //   );
//     // Broadcast preparation times to connected clients via WebSocket (if available)
//     const preparationTimesMessage = JSON.stringify(preparationTimes);
//     if (wss) {
//       wss.clients.forEach((client) => {
//         if (client.readyState === WebSocket.OPEN) {
//           client.send(preparationTimesMessage);
//         }
//       });
//     }
//     // Save the updated order
//     const updatedOrder = await orderToUpdate.save();
//     res.status(200).json({ message: "Order updated", order: updatedOrder });
//   } catch (error) {
//     console.error("Error updating order:", error);
//     res.status(500).json({ error: "Unable to update order." });
//   }
// };
const updateOrderFromAdmin = async (req, res) => {
  try {
    const adminId = req.user.id; // Assuming admin ID is available in the token payload
    const orderIdToUpdate = req.params.orderId; // Assuming the order ID is in the request URL parameters
    const { delivery_id } = req.body; // Extracting delivery_id from the request body
    // Find the order to update
    const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

    if (!orderToUpdate) {
      return res.status(404).json({ error: "Order not found." });
    }

    // Update order status to 'accepted'
    orderToUpdate.status = "accepted";

    // Assign delivery_id if provided in the request body
    if (delivery_id) {
      orderToUpdate.delivery_id = delivery_id;
    }
    orderToUpdate.admin_id = adminId;

    // Save the updated order
    const updatedOrder = await orderToUpdate.save();

    // Logic to update status in intervals (every minute) until status is 'delivered' or 'cancel'
    const statuses = [
      "preparing",
      "packing",
      "pickup",
      "on the way",
      "delivered",
      "cancel",
    ];
    let currentIndex = 0;

    const updateStatusInterval = setInterval(async () => {
      if (
        currentIndex < statuses.length &&
        orderToUpdate.status !== "delivered" &&
        orderToUpdate.status !== "cancel"
      ) {
        orderToUpdate.status = statuses[currentIndex];

        // If the status is "cancel," clear the interval immediately
        if (orderToUpdate.status === "cancel") {
          clearInterval(updateStatusInterval);
        }

        await orderToUpdate.save();

        // Broadcast updated status to connected clients via WebSocket (if available)
        const statusMessage = JSON.stringify({ status: orderToUpdate.status });
        if (wss) {
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              console.log(statusMessage, "uiuiu");
              client.send(statusMessage);
            }
          });
        }

        currentIndex++;
      } else {
        clearInterval(updateStatusInterval);
      }
    }, 60000); // Update status every 1 minute (60000 milliseconds)

    res.status(200).json({ message: "Order updated", order: updatedOrder });
  } catch (error) {
    console.error("Error updating order:", error);
    res.status(500).json({ error: "Unable to update order." });
  }
};
const getOrdersByUser = async (req, res) => {
  try {
    // Check if user ID is provided in the request params
    const userId = req.user.id;

    if (!userId) {
      return res.status(400).json({ error: "User ID not provided" });
    }

    // Fetch all orders for the specified user
    const userOrders = await FoodOrder.find({ user: userId });

    if (userOrders.length === 0) {
      return res.status(404).json({ error: "No orders found for the user" });
    }

    // Map over user orders and fetch additional details from referenced models
    const ordersWithDetails = await Promise.all(
      userOrders.map(async (order) => {
        const addressDetails = order.address_id ? await Address.findOne({ _id: order.address_id }) : null;
        console.log(addressDetails, "addressdetails")
        const cartDetails = order.cart_id ? await cart.findOne({ _id: order.cart_id }) : null;
        console.log(cartDetails, "cartDetails");
        const userDetails = order.user ? await User.findOne({ _id: order.user }) : null;
        console.log(userDetails);
        // Extract specific details from order
        const { address_id, cart_id, user, ...orderDetails } = order.toObject();

        // Return the order with details
        return {
          order: {
            ...orderDetails,
            address: addressDetails,
            cart: cartDetails,
            user: userDetails
          }
        };
      })
    );
    console.log(ordersWithDetails, "kook")
    // Send the array of orders with details in the response
    res.status(200).json({ orders: ordersWithDetails });
  } catch (error) {
    console.error("Error fetching user orders:", error);
    res.status(500).json({ error: "Unable to fetch user orders." });
  }
};


// const getAllorder = async (req, res) => {
//   try {
//     const orders = await FoodOrder.find();
//     res.status(200).json({ message: orders });
//   } catch (error) {
//     console.error("Error fetching orders:", error);
//     res.status(500).json({ error: "Unable to fetch orders." });
//   }
// };
const getAllorder = async (req, res) => {
  const orderId = req.query.orderid;
  const restaurantId = req.query.restaurantid;

  try {
    let orderQuery = {};

    if (restaurantId) {
      orderQuery = { restaurant_id: restaurantId };
    }
    // if (restaurantId) {
    //   // Convert restaurantId to ObjectId
    //   const objectId = new ObjectId(restaurantId);
    //   orderQuery = { restaurant_id: objectId };
    // }
    if (orderId) {
      orderQuery.orderId = orderId;
    }

    const order = await FoodOrder.find(orderQuery).sort({ updated_at: -1 });
    console.log(order)
    if (!order || order.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const orderDetails = order.map((cartid) => cartid.cart_id);
    console.log(orderDetails, "orderdetails");

    const cartDetails = await cart.find({ _id: { $in: orderDetails }, is_active: false });
    console.log(cartDetails, "cartdetails");


    if (!cartDetails || cartDetails.length === 0) {
      return res.status(404).json({ message: "Cart details not found" });
    }

    const quantity = await cart.aggregate([
      {
        $match: {
          _id: { $in: orderDetails },
          is_active: false,
        },
      },
      { $unwind: "$items" },
      {
        $group: {
          _id: "$items.menu_item_id",
          totalQuantity: { $sum: "$items.quantity" },
        },
      },
    ]);

    const totalSumQuantity = quantity.reduce((sum, item) => sum + item.totalQuantity, 0);
    const menuitem = quantity.map((menuid) => menuid._id);

    const menuitems = await MenuItem.find({ _id: { $in: menuitem }, is_active: true });

    if (menuitems.length === 0) {
      return res.status(404).json({ message: "Menu items are not found" });
    }

    const response = { order, cartDetails, quantity, totalSumQuantity, menuitems };
    res.status(200).json({ message: "Food Order Details", response });
  } catch (error) {
    console.log("Error", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

const getOrderById = async (req, res) => {
  try {
    const orderId = req.params.orderId;
    // Fetch order by orderId
    const order = await FoodOrder.findOne({ orderId });

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    // Fetch details from referenced models
    const addressDetails = order.address_id ? await Address.findOne({ _id: order.address_id }) : null;
    const cartDetails = order.cart_id ? await cart.findOne({ _id: order.cart_id }) : null;
    const userDetails = order.user ? await User.findOne({ _id: order.user }) : null;

    // Extract specific details from order
    const { address_id, cart_id, user, ...orderDetails } = order.toObject();

    // Include details in the response
    res.status(200).json({
      order: {
        ...orderDetails,
        address: addressDetails,
        cart: cartDetails,
        user: userDetails
      }
    });
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({ error: "Unable to fetch order." });
  }
};
const cancelOrderFromUser = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming user ID is available in the token payload
    const orderIdToCancel = req.params.orderId; // Assuming the order ID is in the request URL parameters

    // Find the order to cancel
    let orderToCancel = await FoodOrder.findOne({ orderId: orderIdToCancel, user: userId });

    if (!orderToCancel) {
      return res.status(404).json({ error: "Order not found or unauthorized." });
    }

    const { error: validationError, value: updatedOrderData } = foodOrderJoiSchema.validate(req.body, {
      abortEarly: false, // Validate all fields, not just the first one that fails
      allowUnknown: true, // Allow unknown fields that are not defined in the schema
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Update order status to 'cancel' and set the user's response for canceling the order
    updatedOrderData.status = "cancel";
    orderToCancel = await FoodOrder.findOneAndUpdate(
      { orderId: orderIdToCancel, user: userId },
      updatedOrderData,
      { new: true }
    );

    res.status(200).json({ message: "Order canceled", order: orderToCancel });
  } catch (error) {
    console.error("Error canceling order:", error);
    res.status(500).json({ error: "Unable to cancel order." });
  }
};
const cancelOrderByAdmin = async (req, res) => {
  try {
    const adminId = req.user.id; // Assuming admin ID is available in the token payload
    const orderIdToCancel = req.params.orderId; // Assuming the order ID is in the request URL parameters

    // Find the order to cancel
    let orderToCancel = await FoodOrder.findOne({ orderId: orderIdToCancel });
    console.log(orderToCancel, "odwnkjfdjiosdn");
    if (!orderToCancel) {
      return res.status(404).json({ error: "Order not found." });
    }

    const { error: validationError, value: updatedOrderData } = foodOrderJoiSchema.validate(req.body, {
      abortEarly: false, // Validate all fields, not just the first one that fails
      allowUnknown: true, // Allow unknown fields that are not defined in the schema
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Update order status to 'cancel' and set the admin's reason for canceling the order
    updatedOrderData.status = "cancel";
    updatedOrderData.reason_for_cancel_byadmin = req.body.reason_for_cancel_byadmin; // Admin's reason for cancellation
    updatedOrderData.updated_by = adminId; // Update the 'updated_by' field with admin's ID

    orderToCancel = await FoodOrder.findOneAndUpdate(
      { orderId: orderIdToCancel },
      updatedOrderData,
      { new: true }
    );

    res.status(200).json({ message: "Order canceled by admin", order: orderToCancel });
  } catch (error) {
    console.error("Error canceling order by admin:", error);
    res.status(500).json({ error: "Unable to cancel order by admin." });
  }
};

const getOrderByAdmin = async (req, res) => {
  const adminId = req.user.id
  if (!adminId) {
    return res.status(400).json({ message: "Token Not Provided" })
  }
  try {
    const order = await FoodOrder.findOne({ admin_id: adminId })
    const carts = await cart.findOne({ _id: order.cart_id })
    const users = await user.findOne({ _id: order.user })
    res.status(200).json({
      message: "get completed",
      orderid: order._id,
      time: order.created_at,
      firstname: users.firstName,
      lastname: users.lastName,
      mobile: users.mobile,
      email: users.email, carts
    })
  } catch (err) {
    console.log(err)
    res.status(500).json({ message: "Internal Server Error", err })
  }
}
const overallReports = async (req, res) => {
  try {
    // Validate the request body against the Joi schema
    const { error: validationError } = foodOrderJoiSchema.validate(req.body);
    if (validationError) {
      return res.status(400).json({ error: validationError.details[0].message });
    }

    const restaurantId = req.params.restaurant_id;

    // Calculate total order count
    const totalOrderCount = await FoodOrder.countDocuments({ restaurant_id: restaurantId });

    // Calculate overall order amount
    const overallOrderAmountResult = await FoodOrder.aggregate([
      { $match: { restaurant_id: restaurantId } },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const overallOrderAmount = overallOrderAmountResult.length > 0 ? overallOrderAmountResult[0].totalAmount : 0;

    // Calculate cancel order count
    const cancelOrderCount = await FoodOrder.countDocuments({
      restaurant_id: restaurantId,
      status: "cancel",
    });

    // Calculate cancel order total amount
    const cancelOrderAmountResult = await FoodOrder.aggregate([
      { $match: { restaurant_id: restaurantId, status: "cancel" } },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const cancelOrderAmount = cancelOrderAmountResult.length > 0 ? cancelOrderAmountResult[0].totalAmount : 0;

    // Calculate refund order count
    const refundOrderCount = await FoodOrder.countDocuments({
      restaurant_id: restaurantId,
      status: "cancel",
      userresponsefrocancel: "refund",
    });

    // Calculate refund order total amount
    const refundOrderAmountResult = await FoodOrder.aggregate([
      { $match: { restaurant_id: restaurantId, status: "cancel", userresponsefrocancel: "refund" } },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const refundOrderAmount = refundOrderAmountResult.length > 0 ? refundOrderAmountResult[0].totalAmount : 0;

    // Calculate average order size
    const averageOrderSize = totalOrderCount > 0 ? overallOrderAmount / totalOrderCount : 0;

    // Respond with the results
    // return res.json({
    //   success: true,
    //   message: "get order successfully",
    //   totalOrderCount,
    //   overallOrderAmount,
    //   averageOrderSize,
    //   cancelOrderCount,
    //   cancelOrderAmount,
    //   refundOrderCount,
    //   refundOrderAmount,
    // });
    return res.json({
      success: true,
      message: {
        text: "get order successfully",
        additionalInfo: {
          totalOrderCount,
          overallOrderAmount,
          averageOrderSize,
          cancelOrderCount,
          cancelOrderAmount,
          refundOrderCount,
          refundOrderAmount,
        }
      },

    });
  } catch (error) {
    console.error("Error in overall report controller:", error);
    return res.status(500).json({ success: false, error: "Internal Server Error" });
  }
}
const customersDetails = async (req, res) => {
  const adminid = req.user.id;
  const resId = req.params.id;

  // if (!adminid || !resId) {
  //   return res.status(401).json({ message: "Token and resid not provided" });
  // }

  try {
    const carts = await cart.aggregate([
      { $match: { restaurantId: resId, is_active: false } },
    ]);

    const userIds = carts.map((cart) => cart.userId);
    const users = await user.find({ _id: { $in: userIds } });

    const userDetails = users.map((user) => ({
      userId: user._id,
      firstname: user.firstName,
      lastname: user.lastName,
    }));

    const orders = await cart.aggregate([
      { $match: { is_active: false } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 } } },
    ]);

    const totalAmounts = await cart.aggregate([
      { $group: { _id: "$userId", totalAmount: { $sum: "$totalAmount" } } },
    ]);

    const totalAmountsMap = totalAmounts.reduce((acc, entry) => {
      acc[entry._id] = entry.totalAmount;
      return acc;
    }, {});

    const userIdsWithAverage = {};
    Object.keys(totalAmountsMap).forEach((userId) => {
      const totalAmount = totalAmountsMap[userId];
      const orderCount =
        orders.find((order) => order._id === userId)?.orderCount || 0;
      const averageTotalAmount = orderCount > 0 ? totalAmount / orderCount : 0;
      userIdsWithAverage[userId] = averageTotalAmount;
    });

    // res.status(200).json({
    //   message: "Get completed",
    //   customersDetails: userDetails,
    //   orders,
    //   totalAmounts: totalAmountsMap,
    //   averageTotalAmounts: userIdsWithAverage,
    // });
    return res.status(200).json({
      success: true,
      message: {
        text: "Get order successfully.",
        additionalInfo: {
          customersDetails: userDetails,
          orders,
          totalAmounts: totalAmountsMap,
          averageTotalAmounts: userIdsWithAverage,
        },
      },
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
const getCustomerInfo = async (req, res) => {
  const userId = req.params.userid;
  const restaurantId = req.params.restaurantid;
  if (!userId) {
    return res.status(401).json({ message: "Token and userId not provided" });
  }

  try {
    // const userID = new mongoose.Types.ObjectId(userId);
    const users = await user
      .findOne({ _id: userId })
      .select("firstName lastName mobile");
    if (!users) {
      return res.status(404).json({ error: "User not found" });
    }

    const orders = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 } } },
    ]);

    const totalAmounts = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", totalAmount: { $sum: "$totalAmount" } } },
    ]);

    const totalAmountsMap = totalAmounts.reduce((acc, entry) => {
      acc[entry._id] = entry.totalAmount;
      return acc;
    }, {});

    const userIdsWithAverage = {};
    Object.keys(totalAmountsMap).forEach((userId) => {
      const totalAmount = totalAmountsMap[userId];
      const orderCount =
        orders.find((order) => order._id === userId)?.orderCount || 0;
      const averageTotalAmount = orderCount > 0 ? totalAmount / orderCount : 0;
      userIdsWithAverage[userId] = averageTotalAmount;
    });

    const lastOrders = await cart.aggregate([
      { $match: { userId: userId } },
      { $sort: { createdat: -1 } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 }, lastOrder: { $first: "$$ROOT" } } },
    ]);

    const ordersWithVoucher = await cart.aggregate([
      {
        $match: { userId: userId, restaurantId: restaurantId, voucherDiscount: { $exists: true } }
      },
      { $group: { _id: "$userId", totalOrderCount: { $sum: 1 } } },
    ]);

    const ordersWithDiscount = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", totalDiscount: { $sum: "$voucherDiscount" } } },
    ]);

    const orderHistory = await Restaurant.find({ _id: restaurantId }).select("restaurantName");

    const ordersId = await FoodOrder.find({ restaurant_id: restaurantId, user: userId }).select("orderId user status ");

    const TotalOrders = await FoodOrder.aggregate([
      { $match: { restaurant_id: restaurantId, user: userId } },
      { $group: { _id: "$orderId", totalAmount: { $sum: "$total_amount" } } },
    ]);

    const address = await Address.findOne({ user: userId });
    if (!address) {
      return res.status(404).json({ error: "address not found" });
    }

    // res.status(200).json({
    //   customerInfo: users,
    //   TotalOrder: orders,
    //   totalAmount: totalAmountsMap,
    //   orderValue: userIdsWithAverage,
    //   lastOrder: lastOrders,
    //   orderWithVoucher: ordersWithVoucher,
    //   ordersWithDiscount: ordersWithDiscount,
    //   orderHistory,
    //   ordersId,
    //   totalOrderValue: TotalOrders,
    //   address,
    // });
    return res.status(200).json({
      success: true,
      message: {
        text: "Get order successfully.",
        additionalInfo: {
          customerInfo: users,
          TotalOrder: orders,
          totalAmount: totalAmountsMap,
          orderValue: userIdsWithAverage,
          lastOrder: lastOrders,
          orderWithVoucher: ordersWithVoucher,
          ordersWithDiscount: ordersWithDiscount,
          orderHistory,
          ordersId,
          totalOrderValue: TotalOrders,
          address,
        },
      },
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Unable to fetch user." });
  }
};

const totalSalesReport = async (req, res) => {
  const adminId = req.user.id;
  const restaurantId = req.params.id;

  if (!restaurantId && !adminId) {
    return res.status(401).json({
      message:
        "restaurant id is not available in params or authentication issue",
    });
  }
  try {
    const salesReport = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: "delivered",
        },
      },
      {
        $lookup: {
          from: "cartresponse2",
          localField: "cart_id",
          foreignField: "_id",
          as: "cartitem",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "users",
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $group: {
          _id: {
            user: "$user._id",
          },
          salesReport: { $push: "$$ROOT" },
        },
      },
      {
        $project: {
          data: {
            salesReport: "$salesReport",
            cartitem: "$cartitem",
          },
        },
      },
    ]);


    const getrestaurants = await Restaurant.find({ _id: restaurantId });

    const findNetSales = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: "delivered",
        },
      },
      {
        $group: {
          _id: null,
          total_amount: { $sum: "$total_amount" },
        },
      },
    ]);

    const netSales = findNetSales.length > 0 ? findNetSales[0].total_amount : 0;

    res.status(200).json({ message: "salesNet report", salesReport, restaurant: getrestaurants, TotalNetSales: netSales });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "internal server error" });
  }
};

//sales report, rushHours, total order, delivery pending, total delivery
const salesReport = async (req, res) => {
  const adminId = req.user.id;
  const restaurantId = req.params.id;
  if (!adminId || !restaurantId) {
    return res.status(401).json({
      message: "token is not provided in authentication and restaurantid",
    });
  }
  try {
    //today
    const currentDate = new Date();
    console.log(currentDate)
    currentDate.setHours(0, 0, 0, 0);
    //week
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    //month
    const startOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(), 1);

    //get order
    const orderinfo = await FoodOrder.find({
      admin_id: adminId,
      restaurant_id: restaurantId,
    });
    if (!orderinfo && orderinfo) {
      return res.status(401).json({ message: "restaurant id is not found" });
    }

    const cartDetails = orderinfo.map((order) => ({ cart_id: order.cart_id }));
    console.log("lop", cartDetails);

    const totalFinalAmountToday = await cart.aggregate([
      {
        $match: {
          // "items.cart_id": { $in: cartIds },
          createdat: { $gte: currentDate },
          is_active: { $eq: false }
        },
      },
      {
        $group: {
          _id: 0,
          FinalAmountTodaySum: { $sum: "$totalAmount" },
        },
      },
    ]);

    const totalFinalAmountForToday =
      totalFinalAmountToday.length > 0
        ? totalFinalAmountToday[0].FinalAmountTodaySum
        : false || 0;
    console.log("Total Final Amount for Today:", totalFinalAmountForToday);


    const totalFinalAmountThisWeek = await cart.aggregate([
      {
        $match: {
          // "items.cart_id": { $in: cartIds },
          createdat: { $gte: startOfWeek },
          is_active: { $eq: false }
        },
      },
      {
        $group: {
          _id: 0,
          totalFinalAmountThisWeek: { $sum: "$totalAmount" },
        },
      },
    ]);

    const totalFinalAmountForThisWeek =
      totalFinalAmountThisWeek.length > 0
        ? totalFinalAmountThisWeek[0].totalFinalAmountThisWeek
        : 0;
    console.log(
      "Total Final Amount for This Week:",
      totalFinalAmountForThisWeek
    );

    // Calculate total final amount for this month

    const totalFinalAmountThisMonth = await cart.aggregate([
      {
        $match: {
          // "cartitem.cart_id": { $in: cartIds },
          createdat: { $gte: startOfMonth },
          is_active: { $eq: false }
        },
      },
      {
        $group: {
          _id: 0,
          totalFinalAmountThisMonth: { $sum: "$tax_pack_totalamount" },
        },
      },
    ]);

    const totalFinalAmountForThisMonth =
      totalFinalAmountThisMonth.length > 0
        ? totalFinalAmountThisMonth[0].totalFinalAmountThisMonth
        : 0;
    console.log(
      "Total Final Amount for This Month:",
      totalFinalAmountForThisMonth
    );


    const totalDeliveredOrders = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: "delivered",
          created_at: { $gte: currentDate },
        },
      },
      {
        $group: {
          _id: 0,
          totalDeliveredSum: { $sum: 1 },
        },
      },
    ]);

    const totalPendingOrders = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: { $ne: "delivered" },
          created_at: { $gte: currentDate },
        },
      },
      {
        $group: {
          _id: 0,
          totalPendingSum: { $sum: 1 },
        },
      },
    ]);

    const totalDeliveredSum =
      totalDeliveredOrders.length > 0
        ? totalDeliveredOrders[0].totalDeliveredSum
        : 0;
    const totalPendingSum =
      totalPendingOrders.length > 0 ? totalPendingOrders[0].totalPendingSum : 0;

    res.status(200).json({
      message: "restaurant get ok",
      orderinfo,
      totalDeliveredSum,
      totalPendingSum,
      totalFinalAmountForToday,
      totalFinalAmountForThisWeek,
      totalFinalAmountThisMonth
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "internal server error" });
  }
};

//most order food
const mostOrder = async (req, res) => {
  const adminId = req.user.id;
  const restaurantId = req.params.id;
  if (!adminId || !restaurantId) {
    return res
      .status(401)
      .json({
        message: "Token is not provided in authentication and restaurant id",
      });
  }
  try {
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    const startOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(), 1);

    const mostOrderedFood = await cartitem.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          createdat: { $gte: startOfMonth },
          is_active: { $eq: false }
        },
      },
      {
        $unwind: "$items",
      },
      {
        $group: {
          _id: {
            foodName: "$items.menu_item_name",
            category: "$items.additemvariant.category",
          },
          totalPersonOrders: { $addToSet: "$userId" },
          lastOrderTime: { $max: "$createdat" },
        },
      },
      {
        $sort: { totalPersonOrders: -1 },
      },
      {
        $limit: 1,
      },
      {
        $project: {
          _id: 0,
          userId: { $size: "$totalPersons" },
          foodName: "$items.menu_item_name",
          price: "$items.menu_item_price",
          timeDifference: {
            $divide: [
              { $subtract: [new Date(), "$lastOrderTime"] },
              1000 * 60],
          },
        },
      },
    ]);

    const mostOrderedFoodInfo = mostOrderedFood.length > 0 ? mostOrderedFood[0] : null;

    res.status(200).json({
      message: "Most ordered food in the current month retrieved successfully",
      mostOrderedFood: mostOrderedFoodInfo,
    });

  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
const campaignPerReport = async (req, res) => {
  const resId = req.params.id;

  if (!resId) {
    return res.status(401).json({ message: "Restaurant Id not provided" });
  }

  try {
    const restaurantId = await FoodOrder.find({ restaurant_id: resId });
    const resIds = restaurantId.map((cart) => cart.cart_id);

    const users = await cart.find({ _id: { $in: resIds } });

    const restaurantIds = users.map(user => user._id);

    const totalAmounts = await cart.aggregate([
      { $match: { _id: { $in: restaurantIds }, voucherDiscount: { $ne: 0 } } },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$totalAmount" },
          totalVoucherAmount: { $sum: "$voucherDiscount" },
          totalOrdersWithVouchers: { $sum: 1 }
        }
      },
    ]);

    const percentage = totalAmounts.length > 0
      ? (totalAmounts[0].totalOrdersWithVouchers / totalAmounts[0].totalVoucherAmount) * 100
      : 0;

    res.status(200).json({
      message: "get completed",
      ordersWithVoucher: totalAmounts,
      percentageOfOrdersWithVouchers: percentage
    });

  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Unable to fetch." });
  }
};
// const businessreview = async (req, res) => {
//   const restaurantIdString = req.params.id;
//   // Validate and convert restaurant ID to a valid ObjectId
//   if (!mongoose.Types.ObjectId.isValid(restaurantIdString)) {
//     return res.status(401).json({ message: "Invalid restaurant ID" });
//   }
//   try {
//     const restaurantId = new mongoose.Types.ObjectId(restaurantIdString);
//     const restaurantOrders = await FoodOrder.aggregate([
//       {
//         $match: {
//           restaurant_id: restaurantId,
//           status: "delivered",
//         },
//       },
//       {
//         $group: {
//           _id: null,
//           totalOrders: { $sum: 1 },
//           totalRevenue: { $sum: "$total_amount" },
//           averageOrderValue: { $avg: "$total_amount" },
//           ordersPerCustomer: { $addToSet: "$user" },
//           earliestOrderDate: { $min: "$created_at" },
//         },
//       },
//     ]);

//     // Check if there are no orders
//     if (restaurantOrders.length === 0) {
//       return res.status(404).json({ message: "No orders found for the specified restaurant" });
//     }

//     const { totalOrders, totalRevenue, averageOrderValue, ordersPerCustomer, earliestOrderDate } = restaurantOrders[0];

//     res.status(200).json({
//       message: "Review data retrieved successfully",
//       totalOrders,
//       totalRevenue,
//       averageOrderValue,
//       ordersPerCustomer: ordersPerCustomer.length,
//       earliestOrderDate,
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Internal server error" });
//   }
// };
const businessreview = async (req, res) => {
  const restaurantId = req.params.id;
  try {
    // Retrieve all orders for the restaurant using the correct ObjectId
    const restaurantOrders = await FoodOrder.find({ restaurant_id: restaurantId });

    // Check if there are no orders
    if (restaurantOrders.length === 0) {
      return res.status(404).json({ message: "No orders found for the specified restaurant" });
    }
    // Perform aggregation on the retrieved orders
    const aggregatedData = await FoodOrder.aggregate([
      {
        $match: {
          _id: { $in: restaurantOrders.map(order => order._id) },
          status: "delivered", // Use ObjectIds directly
        },
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalRevenue: { $sum: "$total_amount" },
          averageOrderValue: { $avg: "$total_amount" },
          ordersPerCustomer: { $addToSet: "$user" },
          earliestOrderDate: { $min: "$created_at" },
        },
      },
    ]);

    // Access and use the aggregated data
    const { totalOrders, totalRevenue, averageOrderValue, ordersPerCustomer, earliestOrderDate } = aggregatedData[0];

    res.status(200).json({
      message: "Review data retrieved successfully",
      totalOrders,
      totalRevenue,
      averageOrderValue,
      ordersPerCustomer: ordersPerCustomer.length,
      earliestOrderDate,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};
const customerReport = async (req, res) => {
  const restaurantId = req.params.id;
  if (!restaurantId) {
    return res.status(401).json({ message: "Token and restaurantId not provided" });
  }
  try {
    // const restaurantId =new mongoose.Types.ObjectId(restaurantIds)
    const customer = await FoodOrder.find({ restaurant_id: restaurantId });
    if (!customer) {
      return res.status(404).json({ error: " customer not found" });
    }
    res.status(200).json({ message: "get completed", customer });
  } catch (error) {
    console.error("Error fetching customer:", error);
    res.status(500).json({ error: "Unable to fetch customer." });
  }
};

const netSales = async (req, res) => {
  const adminId = req.user.id;
  if (!adminId) {
    return res.status(400).json({ message: "Token not provided" });
  }

  const { timePeriod, restaurantName } = req.query;

  try {
    let filter = { admin_id: adminId };

    // Apply additional filters based on query parameters
    if (timePeriod === 'today') {
      filter.updated_at = { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }; // Today's records
    } else if (timePeriod === 'thisWeek') {
      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      filter.updated_at = { $gte: startOfWeek }; // This week's records
    } else if (timePeriod === 'thisMonth') {
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      filter.updated_at = { $gte: startOfMonth }; // This month's records
    }

    if (restaurantName) {
      filter.restaurantName = restaurantName;
    }

    // Find all restaurants belonging to the admin with optional filters
    const restaurants = await Restaurant.find(filter);

    // Iterate through each restaurant to calculate net sales
    const netSalesReports = [];
    for (const restaurant of restaurants) {
      // Find orders and carts for the current restaurant
      const orders = await FoodOrder.find({ restaurant_id: restaurant._id });
      const carts = await cart.find({ is_active: false, restaurant_id: restaurant._id });

      // Calculate total net sales for the restaurant
      const totalNetSales = carts.reduce((acc, cart) => acc + cart.totalAmount, 0);

      // Calculate total delivery fee and tax from carts
      let totalDeliveryFee = 0;
      let totalTax = 0;
      let discount = 0;
      let FoodOrderAmount = 0;
      let totalFoodAmount = 0;
      for (const cart of carts) {
        totalDeliveryFee += cart.deliveryfee || 0;
        totalTax += cart.vat_tax || 0;
        FoodOrderAmount += cart.totalAmount || 0;
        totalFoodAmount += cart.tax_pack_totalamount || 0;
      }

      // Get the last updated order details
      const lastUpdatedOrder = orders.length > 0 ? orders[orders.length - 1] : null;

      // Extract details from the last updated order
      const lastUpdatedOrderId = lastUpdatedOrder ? lastUpdatedOrder.orderId : null;
      const lastUpdatedOrderStatus = lastUpdatedOrder ? lastUpdatedOrder.status : null;
      const lastUpdatedOrderPaymentType = lastUpdatedOrder ? lastUpdatedOrder.paymentType : null;
      const lastUpdatedOrderDeliveryType = lastUpdatedOrder ? lastUpdatedOrder.deliveryType : null;
      const lastUpdatedOrderUpdatedAt = lastUpdatedOrder ? lastUpdatedOrder.updated_at : null;

      // Get the last updated user details for the cart
      const lastUpdatedUser = await User.findById(carts[carts.length - 1]?.userId); // Fetch user details based on userId

      // Push the net sales report for the restaurant
      netSalesReports.push({
        restaurant_id: restaurant._id,
        restaurantName: restaurant.restaurantName,
        totalNetSales: totalNetSales,
        restaurantTimeend: restaurant.updated_at,
        restaurantTimestart: restaurant.created_at,
        deliveryfee: totalDeliveryFee,
        tax: totalTax,
        cartDiscount: discount,
        FoodOrderAmount: FoodOrderAmount,
        totalFoodAmount: totalFoodAmount,
        lastUpdatedUser: lastUpdatedUser
          ? {
            _id: lastUpdatedUser._id,
            firstName: lastUpdatedUser.firstName,
            lastName: lastUpdatedUser.lastName,
            phone: lastUpdatedUser.mobile,
          }
          : null, // Include last updated user details
        lastUpdatedOrderId: lastUpdatedOrderId,
        lastUpdatedOrderStatus: lastUpdatedOrderStatus,
        lastUpdatedOrderPaymentType: lastUpdatedOrderPaymentType,
        lastUpdatedOrderDeliveryType: lastUpdatedOrderDeliveryType,
        lastUpdatedOrderUpdatedAt: lastUpdatedOrderUpdatedAt,
        //salestotal: netSalesReports,
      });
    }

    // Send the net sales reports for all restaurants
    res.status(200).json({ message: "Net sales reports", netSalesReports });
  } catch (error) {
    console.log("error", error)
    res.status(500).json({ message: 'internal server error' })
  }

}
const livenotificationforadmin = async (req, res) => {
  try {
    const restaurantId = req.params.restaurantId;
    let orders;

    const sendOrdersToClientss = async () => {
      try {
        orders = await FoodOrder.find({
          restaurant_id: restaurantId,
          status: "pending",
        }).sort({ updated_at: -1 });
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ message: "New orders received", orders }));
          }
        });
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    // Periodically update orders every 2 seconds
    const intervalId = setInterval(sendOrdersToClientss, 2000);

    // Call the function immediately to send initial orders
    await sendOrdersToClientss();

    // Respond to the client
    res.status(200).json({ message: "ok", orders });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "internal server error" });
  }
};
module.exports = {
  createOrder,
  setWebSocketServer,
  updateOrderFromAdmin,
  getOrdersByUser,
  getAllorder,
  getOrderById,
  cancelOrderFromUser,
  cancelOrderByAdmin,
  getOrderByAdmin,
  overallReports,
  customersDetails,
  getCustomerInfo,
  totalSalesReport,
  salesReport,
  mostOrder,
  campaignPerReport,
  businessreview,
  customerReport,
  netSales,
  livenotificationforadmin,
};
