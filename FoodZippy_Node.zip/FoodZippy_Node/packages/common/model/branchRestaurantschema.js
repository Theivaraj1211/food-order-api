const mongoose = require("mongoose");

const breachResturantSchema = new mongoose.Schema({
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Admin",
    },
    logoImage: {
        data: Buffer,
        contentType: String,
    },
    imageURL: {
        type: String,
    },
    restaurantName: {
        type: String,
    },
    address: {
        type: String,
    },
    currency: {
        type: String,
    },
    city: {
        type: String,
    },
    zipcode: {
        type: String,
    },
    mobile: { // Change phone_number to mobile object
        countryCode: {
            type: String,
        },
        phoneNumber: {
            type: String, // Changed to String to preserve leading zeros
        },
    },
    is_active: {
        type: Boolean,
        default: true,
    },
    mapLocation: {
        lat: {
            type: Number,
        },
        long: {
            type: Number,
        },
    },
    storetimezone: {
        type: Date,
        default: () => new Date(),
    },
    serviceDescription: {
        type: String
    },
    facilities: {
        type: String
    },
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
    publishRestaurant: {
        type: Boolean,
        default: false,
    }
})
const branchRestaurant = mongoose.model('breachRestaurant', breachResturantSchema);
module.exports = branchRestaurant;