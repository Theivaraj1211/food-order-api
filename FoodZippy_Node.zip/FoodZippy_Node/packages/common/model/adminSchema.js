const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    email: { type: String, unique: false },
    password: { type: String },
    firstname: { type: String },
    lastname: { type: String },
    gender: { type: String },
    mobile: { type: String },
    country: { type: String },
    ipaddress: { type: String },
    is_active: { type: Boolean, default: false },
    otp: { type: String },
    otp_time_out: { type: Boolean, default: false },
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
});

const Admin = mongoose.model('Admin', adminSchema);

module.exports = Admin;