const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  mobile: { // Change phone_number to mobile object
    countryCode: {
      type: String,
    },
    phoneNumber: {
      type: String, // Changed to String to preserve leading zeros
    },
  },
  otp: {
    type: Number
  },
  image: {
    data: Buffer,
    contentType: String,
  },
  imageURL: {
    type: String,
  },
  others: {
    friends: {
      type: [String],
    },
    family: {
      type: [String],
    },
  },
  email: {
    type: String,
  },
  created_at: {
    type: Date,
    default: () => new Date(),
  },
  updated_at: {
    type: Date,
    default: () => new Date(),
  },
  is_active: {
    type: Boolean,
    default: false,
  },
  addresses: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Address',
    },
  ],
  ipaddress: {
    type: String,
  }
});

const User = mongoose.model('user', userSchema);

module.exports = User;
