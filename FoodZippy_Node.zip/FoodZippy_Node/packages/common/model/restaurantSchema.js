// Import the Mongoose library
const mongoose = require('mongoose');

// Define the restaurantLog schema
const restaurantLogSchema = new mongoose.Schema({
    logoImage: {
        data: Buffer,
        contentType: String,
    },
    imageURL: {
        type: String,
    },
    restaurantName: {
        type: String,
    },
    address: {
        type: String,
    },
    currency: {
        type: String,
    },
    city: {
        type: String,
    },
    zipcode: {
        type: String,
    },
    mobile: { // Change phone_number to mobile object
        countryCode: {
            type: String,
        },
        phoneNumber: {
            type: String, // Changed to String to preserve leading zeros
        },
    },
    is_active: {
        type: Boolean,
    },
    mapLocation: {
        lat: {
            type: Number,
        },
        long: {
            type: Number,
        },
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Admin',
    },
    storetimezone: {
        type: Date,
        default: () => new Date(),
    },
    serviceDescription: {
        type: String
    },
    facilities: {
        type: String
    },
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
});

// Create a Mongoose model using the schema
const RestaurantLog = mongoose.model('Restaurant', restaurantLogSchema);

// Export the model
module.exports = RestaurantLog;
