const mongoose = require("mongoose");

const voucherSchema = mongoose.Schema(
  {
    createDiscount: {
      type: String,
      enum: ["Percentage", "lump"],
    },
    voucherCodes: {
      type: String,
    },
    expirationDate: {
      type: Date,
      default: () =>
        new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
    is_Active: {
      type: Boolean,
      default: true,
    },
    restaurantName: {
      type: String,
    },
    admin_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
    },
    restaurantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Restaurant",
    },
    minimumOrderValue: {
      type: Number,
    },
    minimumOrderValue_active: {
      type: Boolean,
      default: true,
    },
    theVoucherCanBeUser: {
      type: String,
      enum: ["onlyOnce"],
    },
    discountPercentage: {
      type: Number,
    },
    created_by: {
      type: String,
    },
    updated_by: {
      type: String,
    },
    lumpAmount: {
      type: Number,
    },
    validDateFrom: {
      type: Date,
      default: Date.now(),
    },
    validDateTo: {
      type: Date,
      default: Date.now(),
    },
    validTimeFrom: {
      type: Date,
      default: Date.now(),
    },
    validTimeTo: {
      type: Date,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
  }
);

const voucherCode = mongoose.model("vouchercodes", voucherSchema);

module.exports = voucherCode;
