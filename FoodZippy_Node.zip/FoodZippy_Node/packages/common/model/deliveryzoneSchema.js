const mongoose = require('mongoose');

const locationPointSchema = new mongoose.Schema({
    lat: { type: Number, },
    long: { type: Number, },
});

const circleDeliveryZoneSchema = new mongoose.Schema({
    userLat: { type: Number, },
    userLong: { type: Number, },
    deliveryFee: { type: Number, },
    minimumOrder: { type: Number },
    shape: { type: String, enum: ['circle'], },
    center: {
        latitude: { type: Number },
        longitude: { type: Number },
    },
    radius: { type: Number },
    is_active: { type: Boolean, default: true },
});

const customDeliveryZoneSchema = new mongoose.Schema({
    userLat: { type: Number, },
    userLong: { type: Number, },
    deliveryFee: { type: Number, },
    minimumOrder: { type: Number },
    shape: { type: String, enum: ['custom'], },
    locationPoints: { type: [locationPointSchema], },
    is_active: { type: Boolean, default: true },
});

const deliveryZonesSchema = new mongoose.Schema({
    deliveryZones: {
        type: [
            {
                type: { type: String, enum: ['circle', 'custom'], },
                userLat: { type: Number, },
                userLong: { type: Number, },
                deliveryFee: { type: Number, },
                minimumOrder: { type: Number },
                radius: { type: Number },
                locationPoints: { type: [locationPointSchema] },
            },
        ],
    },
    admin_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin', },
    restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', },
    createdBy: {
        type: String,
        enum: ["admin", "manager"],
        default: "admin"
    },
    updatedBy: {
        type: String,
        enum: ["admin", "manager"],
        default: "admin"
    },
    createdat: {
        type: Date,
        default: Date.now()
    },
    updatedat: {
        type: Date,
        default: Date.now()
    }
});

const DeliveryZones = mongoose.model('DeliveryZones', deliveryZonesSchema);

module.exports = DeliveryZones;
