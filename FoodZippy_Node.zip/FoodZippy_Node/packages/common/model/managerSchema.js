const mongoose = require('mongoose');

const managerSchema = mongoose.Schema({
    userName: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    restaurantName: {
        type: String
    },
    userType: {
        type: String,
        enum: ["manager", "admin"],
        default: "admin"
    },
    userAddress: {
        type: String
    },
    userPhoneNumber: {
        type: Number
    },
    joinDate: {
        type: Date,
        default: Date.now()
    },
    isActive: {
        type: Boolean,
        default: true
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Admin'
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant'
    },
    createdBy: {
        type: String,
        default: "admin"
    },
    updatedBy: {
        type: String,
        default: "admin2"
    },
}, {
    timestamps: true
});

module.exports = mongoose.model('Manager', managerSchema);