// const mongoose = require("mongoose");

// const CartItemSchema = new mongoose.Schema({
//   menu_item_id: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "MenuItem",
//   },
//   menuprice: {
//     type: Number,
//     ref: "MenuItem.itemPrice",
//   },
//   additemvariant_id: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "MenuItem.additemvariant",
//   },
//   additemvariantprice: {
//     type: Number,
//     ref: "MenuItem.price",
//   },
//   addons_id: [
//     {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "MenuItem.addons",
//     },
//   ],
//   addonsprice: [
//     {
//       type: Number,
//       ref: "MenuItem.addonPrice",
//     },
//   ],
//   totalAmountofmenu: {
//     type: Number,
//   },
//   quantity: {
//     type: Number,
//     default: 1,
//   },
// });

// const AddToCartItemSchema = new mongoose.Schema(
//   {
//     user_id: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "user",
//     },
//     vouchercode_id: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "vouchercodes",
//     },
//     vouchercode: {
//       type: String,
//     },
//     addcartitem: {
//       type: [[CartItemSchema]],
//     },
//     cookingInstruction: {
//       type: String,
//     },
//     is_active: {
//       type: Boolean,
//       default: true,
//     },
//     tax: {
//       type: Number,
//     },
//     packingCharge: {
//       type: Number,
//     },
//     totalAmount: {
//       type: Number,
//     },
//     takeawaye: {
//       type: Boolean,
//       default: false,
//     },
//     delivery: {
//       type: Boolean,
//       default: true,
//     },
//   },
//   { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
// );

// const Addcartitem = mongoose.model("Addcartitem", AddToCartItemSchema);

// module.exports = Addcartitem;
const mongoose = require("mongoose");
const cartItemVariantSchema = new mongoose.Schema(
  {
    category: String,
    itemName: String,
    price: Number,
    type: String,
    isActive: Boolean,
    _id: mongoose.Schema.Types.ObjectId,
    created_at: Date,
    updated_at: Date,
  },
  { _id: false }
); // To prevent Mongoose from automatically creating a new _id for each variant

const cartItemAddonSchema = new mongoose.Schema(
  {
    addonName: String,
    addonPrice: Number,
    is_active: Boolean,
    // _id: mongoose.Schema.Types.ObjectId,
    _id: String,
  },
  { _id: false }
); // To prevent Mongoose from automatically creating a new _id for each addon

const cartItemSchema = new mongoose.Schema({
  menu_item_id: mongoose.Schema.Types.ObjectId,
  menu_item_name: String,
  menu_item_price: Number,
  quantity: Number,
  additemvariant: [cartItemVariantSchema],
  addons: [cartItemAddonSchema],
  subtotal: Number,
});

const cartResponseSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  totalAmount: Number,
  cookingInstruction: String,
  voucherDiscount: Number,
  vouchercode_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "vouchercodes",
  },
  vouchercode: {
    type: String,
  },
  finalAmount: Number,
  items: [cartItemSchema],
  is_active: {
    type: Boolean,
    default: true,
  },
  takeawaye: {
    type: Boolean,
    default: false,
  },
  delivery: {
    type: Boolean,
    default: true,
  },
  createdat: {
    type: Date,
    default: Date.now()
  },
  updatedat: {
    type: Date,
    default: Date.now()
  },
  packingCharge: {
    type: Number,
  },
  vat_tax: {
    type: Number,
  },
  tax_pack_totalamount: {
    type: Number,
  },
  restaurant_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant', // Reference to the Restaurant model if you have one
  },
  deliveryfee: {
    type: Number,
  },
});

module.exports = mongoose.model("CartResponse2", cartResponseSchema);
