const mongoose = require("mongoose");

const RetentionSchema = new mongoose.Schema({
  admin_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Admin",
  },
  restaurant_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Restaurant",
  },
  restaurantName: String,
  discountCode: String,
  amountOfDiscount: String,
  voucherValid: String,
  campaignEnable: Boolean,
  deliveryfee: Boolean,
  automaticOrder: Boolean,
  is_Active: Boolean,
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
  created_by: String,
  updated_by: String,
});

const Retention = mongoose.model("Retention", RetentionSchema);

module.exports = Retention;
