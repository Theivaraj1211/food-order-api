const mongoose = require("mongoose");
const servicechargeschema = new mongoose.Schema({
    enbale_service_charge: {
        type: Boolean,
        default: false
    },
    service_rate: {
        type: Number,
    },
    hide: {
        type: Boolean,
        default: false,
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Admin",
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Restaurant",
    },
    vat_tax: {
        type: Number,
    },
    is_created: {
        type: Date,
    },
    is_updated: {
        type: Date,
    },
    created_by: {
        type: String,
    },
    updated_by: {
        type: String,
    },
});
const Servicecharge = mongoose.model('servicecharge', servicechargeschema);

module.exports = Servicecharge;