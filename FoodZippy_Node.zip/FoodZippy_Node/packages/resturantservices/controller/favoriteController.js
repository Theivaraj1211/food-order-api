const Joi = require("joi");
const FavoriteItem = require("../../common/model/favoriteSchema"); // Import your Mongoose model
const menu = require("../../common/model/menuSchema");

const favoriteValidationSchema = Joi.object({
  user_id: Joi.string(),
  menu_item_id: Joi.string(),
  is_favorite: Joi.boolean(),
  // Other validations for additional fields specific to favorite item
});

// Controller method to create a favorite item
const createFavoriteItem = async (req, res) => {
  try {
    // Validate the incoming data using Joi schema
    const { error } = favoriteValidationSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    // Extract user_id from the request object (obtained from token via middleware)
    const userId = req.user;
    console.log(userId, "hudbsu");
    console.log("hoolonhh");
    // Extract necessary data from the request body
    const { menu_item_id, is_favorite } = req.body;
    // Check if the favorite item already exists for the user with the given menu_item_id
    const existingFavorite = await FavoriteItem.findOne({ menu_item_id });

    if (existingFavorite) {
      return res.status(400).json({
        error: "Favorite item for this menu item already exists for the user",
      });
    }

    // Create a new instance of the Mongoose model 'FavoriteItem'
    const newFavoriteItem = new FavoriteItem({
      menu_item_id,
      is_favorite: is_favorite || false,
    });
    newFavoriteItem.user_id = userId;
    // Save the favorite item to the database
    const savedFavoriteItem = await newFavoriteItem.save();

    res.status(201).json({
      message: "Favorite item created successfully",
      favoriteItem: savedFavoriteItem,
    });
  } catch (error) {
    console.error("Error creating favorite item:", error);
    res.status(500).json({ error: "Could not create favorite item" });
  }
};
const getFavoriteItemsByUserId = async (req, res) => {
  const userId = req.user;
  console.log("userid", userId)
  try {
    // Extract user_id from the request object (obtained from token via middleware)
    // Find all favorite items for the user based on the user_id
    const favoriteItems = await FavoriteItem.find({
      user_id: userId,
      is_favorite: true,
    });
    // Extract menu_item_ids from favoriteItems
    const menu_item_ids = favoriteItems.map((item) => item.menu_item_id);

    // Fetch menu items using the extracted menu_item_ids
    const favoritemenu = await menu.find(
      { _id: { $in: menu_item_ids } }, // Filter by menu_item_ids
      { itemName: true, itemPrice: 1, itemImage: 1, description: true, _id: 0 } // Projection: 1 to include, 0 to exclude
    );
    res.status(200).json({ favoriteItems, favoritemenu });
  } catch (error) {
    console.error("Error fetching favorite items:", error);
    res.status(500).json({ error: "Could not fetch favorite items" });
  }
};
const updateFavoriteItem = async (req, res) => {
  try {
    const { favoriteItemId, is_favourite } = req.body;
    // Find the specific favorite item by its _id and user_id
    const favoriteItem = await FavoriteItem.findOne({ _id: favoriteItemId });

    if (!favoriteItem) {
      return res
        .status(404)
        .json({ error: "Favorite item not found for the user" });
    }

    // Delete the found favorite item
    await FavoriteItem.deleteOne({ _id: favoriteItemId });

    res.status(200).json({ message: "Favorite item remove successfully" });
  } catch (error) {
    console.error("Error deleting favorite item:", error);
    res.status(500).json({ error: "Could not delete favorite item" });
  }
};

module.exports = {
  createFavoriteItem,
  getFavoriteItemsByUserId,
  updateFavoriteItem,
};
