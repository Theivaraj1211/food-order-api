const Joi = require("joi");
const Menu = require("../../common/model/menuSchema");
//const AddItemVariants = require("../../common/model/addItemVariantSchema ");
const Address = require("../../common/model/addressSchema");
const restaurant = require("../../common/model/restaurantSchema");
const User = require("../../common/model/userSchema");
const fs = require("fs");
const path = require("path");
const menuItemJoiSchema = Joi.object({
  categoryName: Joi.string(),
  itemName: Joi.string(),
  itemAvailableTime: Joi.string(),
  itemAvailableTimefrom: Joi.string(),
  itemAvailableTimeto: Joi.string(),
  preparationTime: Joi.string(),
  description: Joi.string(),
  itemImage: Joi.object({
    data: Joi.binary(),
    contentType: Joi.string(),
  }),
  imageURL: Joi.string(),
  itemType: Joi.string().valid("vegetarian", "non vegetarian", "vegan"),
  itemPrice: Joi.number(),
  is_active: Joi.boolean(),
  discountPriceAvailable: Joi.boolean(),
  discountPriceAmount: Joi.number(),
  packingCharge: Joi.number(),
  admin_id: Joi.string(),
  restaurant_id: Joi.string(),
  additemvariant: Joi.array().items(
    Joi.object({
      category: Joi.string(),
      itemName: Joi.string(),
      price: Joi.number(),
      type: Joi.string().valid("vegetarian", "non vegetarian", "vegan"),
      isActive: Joi.boolean(),
      created_at: Joi.date(),
      updated_at: Joi.date(),
    })
  ),
  // combo: Joi.array().items(
  //   Joi.object({
  //     comboItems: Joi.array().items(Joi.string()),
  //     is_active: Joi.boolean(),
  //     comboPrice: Joi.number(),
  //   })
  // ),
  addons: Joi.array().items(
    Joi.object({
      addonName: Joi.string(),
      addonPrice: Joi.number(),
    })
  ),
  created_at: Joi.date(),
  updated_at: Joi.date(),
});

const createMenuItem = async (req, res) => {
  try {
    const admin_id = req.user;
    // Validate the request body using Joi
    const { error, value } = menuItemJoiSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    // Check if a menu item with the same name already exists
    const existingMenuItem = await Menu.findOne({ itemName: value.itemName });
    if (existingMenuItem) {
      return res
        .status(400)
        .json({ error: "Menu item with the same name already exists" });
    }
    // Create a new menu item based on the validated request data
    const newMenuItem = new Menu(value);
    newMenuItem.admin_id = admin_id;
    // Handle the uploaded image
    if (req.file) {
      newMenuItem.itemImage.data = req.file.buffer;
      newMenuItem.itemImage.contentType = req.file.mimetype;
    }
    newMenuItem.itemName = value.itemName;
    const imageFileName = `${newMenuItem._id}_${Date.now()}.${
      req.file.originalname
    }`;
    const imagePath = `/uploads/${imageFileName}`; // Relative path to the image
    newMenuItem.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
    // Save the menu item to the database
    const savedItem = await newMenuItem.save();
    res.status(201).json(savedItem);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};
// Define a controller function to get menu items by restaurant_id
const getMenuItemsByRestaurantId = async (req, res) => {
  console.log("jasjinja");
  try {
    const { id } = req.params; // Access 'id' directly instead of an object containing 'id'
    console.log("Requested Restaurant ID:", id);
    // Find all menu items for the specified restaurant_id
    const menuItems = await Menu.find({ restaurant_id: id });
    console.log("Found Menu Items:", menuItems);

    // If no menu items found for the specified restaurant_id, return a 404 Not Found
    if (!menuItems || menuItems.length === 0) {
      return res.status(404).json({
        error: "Menu items not found for the specified restaurant_id",
      });
    }

    // Return the found menu items in a 200 OK response
    return res.status(200).json({ menuItems });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal server error" });
  }
};
// const getallmenuwithUserLocation = async (req, res) => {
//     try {
//         const userId = req.user;
//         const user = await User.findById(userId).populate('addresses');
//         console.log(user, "huheh");
//         if (!user) {
//             return res.status(404).json({ message: 'User not found' });
//         }

//         // Filter the user's addresses to find the default one
//         const defaultAddress = user.addresses.find(address => address.is_default);

//         if (!defaultAddress) {
//             return res.status(404).json({ message: 'Default address not found for the user' });
//         }
//         console.log(defaultAddress, "uewjahbuygyyu")
//         const userLocation = {
//             lat: defaultAddress.location.lat,
//             long: defaultAddress.location.long
//         };
//         console.log(userLocation, "345678")
//         const radius_5km = 5 * 1000; // 5 kilometers converted to meters
//         const radius_10km = 10 * 1000; // 10 kilometers converted to meters

//         // Find restaurants within 5km radius from the user's location
//         // const restaurantsWithin5km = await restaurant.find({
//         //     'mapLocation': {
//         //         $geoWithin: {
//         //             $centerSphere: [
//         //                 [userLocation.long, userLocation.lat],
//         //                 radius_5km / 6378.1 // Earth radius in kilometers
//         //             ]
//         //         }
//         //     }
//         // }) // Populate the menu field for each restaurant

//         //Find restaurants within 10km radius from the user's location
//         const restaurantsWithin10km = await restaurant.find({
//             'mapLocation': {
//                 $geoWithin: {
//                     $centerSphere: [
//                         [userLocation.long, userLocation.lat],
//                         radius_10km / 6378.1 // Earth radius in kilometers
//                     ]
//                 }
//             }
//         })///.populate('MenuItem'); // Populate the menu field for each restaurant
//         // Extract restaurant IDs from the found restaurants
//         const restaurantIds = restaurantsWithin10km.map(restaurant => restaurant._id);
//         // Find menu items associated with the extracted restaurant IDs
//         const menuItemsForRestaurants = await Menu.find({ restaurant_id: { $in: restaurantIds } });
//         return res.status(200).json({ message: menuItemsForRestaurants });

//     } catch (error) {
//         console.error(error);
//         return res.status(500).json({ message: 'Internal server error' });
//     }
// };
const getallmenuwithUserLocation = async (req, res) => {
  try {
    const userId = req.user;
    const user = await User.findById(userId).populate("addresses");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Filter the user's addresses to find the default one
    const defaultAddress = user.addresses.find((address) => address.is_default);

    if (!defaultAddress) {
      return res
        .status(404)
        .json({ message: "Default address not found for the user" });
    }

    const userLocation = {
      lat: defaultAddress.location.lat,
      long: defaultAddress.location.long,
    };

    // Define the maximum distance (in meters) for user and restaurant locations
    const maxDistance = 50000; // 5 kilometers converted to meters For example, restrict within 10 kilometers (10000 meters)
    console.log(maxDistance, "jandjAR345");
    const restaurantsNearUser = await restaurant.find({
      mapLocation: {
        $geoWithin: {
          $centerSphere: [[userLocation.long, userLocation.lat], maxDistance],
        }, //$maxDistance: maxDistance
      },
    });
    console.log(restaurantsNearUser, "ubhjgyug");
    // Filter the restaurants that are within the specified radius
    const restaurantsWithinRadius = restaurantsNearUser.filter((restaurant) => {
      const restaurantLocation = {
        lat: restaurant.mapLocation.lat,
        long: restaurant.mapLocation.long,
      };
      const distance = calculateDistance(userLocation, restaurantLocation);
      console.log(distance, "hapooo");
      return distance <= maxDistance;
    });

    if (restaurantsWithinRadius.length === 0) {
      return res
        .status(400)
        .json({ message: "No restaurants found within the specified radius" });
    }

    // Extract restaurant IDs from the filtered restaurants within the radius
    const restaurantIds = restaurantsWithinRadius.map(
      (restaurant) => restaurant._id
    );
    console.log(restaurantIds, "happy");
    // Find menu items associated with the extracted restaurant IDs
    const menuItemsForRestaurants = await Menu.find({
      restaurant_id: { $in: restaurantIds },
    });
    console.log(menuItemsForRestaurants, "joi");
    return res.status(200).json({ message: menuItemsForRestaurants });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
function calculateDistance(point1, point2) {
  const { lat: lat1, long: lon1 } = point1;
  const { lat: lat2, long: lon2 } = point2;

  const R = 6371; // Earth's radius in kilometers

  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  const distanceInMeters = distance * 1000; // Convert distance to meters
  return distanceInMeters;
}

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}

const getCategoryNamesByRestaurantId = async (req, res) => {
  const { restaurantId } = req.params; // Assuming the restaurant ID is passed as a parameter

  try {
    const menuItems = await Menu.find({ restaurant_id: restaurantId }); // Assuming MenuItem is your model

    // Extract category names for the given restaurant ID
    const categoryNames = menuItems.map((item) => item.categoryName);

    // Respond with the category names
    res.status(200).json({ message: categoryNames });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};
const getAllMenuItems = async (req, res) => {
  try {
    const menuItems = await Menu.find();
    if (!menuItems || menuItems.length === 0) {
      return res.status(404).json({ error: "No menu items found" });
    }
    return res.status(200).json({ menuItems });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal server error" });
  }
};
module.exports = {
  createMenuItem,
  getMenuItemsByRestaurantId,
  getallmenuwithUserLocation,
  getCategoryNamesByRestaurantId,
  getAllMenuItems,
};
