const Joi = require('joi');
const Servicecharge = require('../../common/model/serviceschargeSchema');

// Joi schema for validating request body
const serviceChargeJoiSchema = Joi.object({
    enable_service_charge: Joi.boolean().default(false),
    service_rate: Joi.number(),
    hide: Joi.boolean().default(false),
    admin_id: Joi.string(),
    restaurant_id: Joi.string(),
    vat_tax: Joi.number(),
    created_by: Joi.string(),
    updated_by: Joi.string(),
});

// Controller to create or update service charge settings
const createOrUpdateServiceCharge = async (req, res) => {
    try {
        const adminId = req.user;
        const requestBody = await serviceChargeJoiSchema.validateAsync(req.body);
        let serviceCharge = await Servicecharge.findOne({ admin_id: adminId, restaurant_id: requestBody.restaurant_id });
        if (serviceCharge) {
            serviceCharge = await Servicecharge.findOneAndUpdate(
                { admin_id: adminId, restaurant_id: requestBody.restaurant_id },
                { $set: { ...requestBody, is_updated: Date.now(), updated_by: adminId } },
                { new: true }
            );
        } else {
            serviceCharge = new Servicecharge({
                ...requestBody,
                admin_id: adminId,
                is_created: Date.now(),
                is_updated: Date.now(),
                created_by: adminId,
                updated_by: adminId,
            });
            await serviceCharge.save();
        }

        res.status(200).json({ message: 'Service charge settings updated successfully', serviceCharge });
    } catch (error) {
        console.error('Error updating service charge settings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }

};

// Controller to get service charge settings by admin_id
const getServiceChargeByAdminId = async (req, res) => {
    try {
        // Extract admin_id from the token or your authentication middleware
        const adminId = req.user; // Replace with your actual way of getting admin_id from token

        // Fetch service charge settings by admin_id
        const serviceCharge = await Servicecharge.findOne({ admin_id: adminId });

        if (!serviceCharge) {
            return res.status(404).json({ error: 'Service charge settings not found' });
        }

        res.status(200).json({ serviceCharge });
    } catch (error) {
        console.error('Error fetching service charge settings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

module.exports = {
    createOrUpdateServiceCharge,
    getServiceChargeByAdminId,
};
