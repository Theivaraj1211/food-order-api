const Joi = require("joi");
const manager = require("../../common/model/managerSchema");
const mailService = require("../../userservices/helper/mail_serverices")

const managerschemas = Joi.object({
    userName: Joi.string(),
    email: Joi.string(),
    password: Joi.string(),
    restaurantName: Joi.string(),
    userType: Joi.string().valid('manager', 'admin'),
    userAddress: Joi.string(),
    userPhoneNumber: Joi.number(),
    joinDate: Joi.date(),
    isActive: Joi.boolean(),
    admin_id: Joi.string(),
    createdBy: Joi.string(),
    updatedBy: Joi.string(),
    restaurant_id: Joi.string(),
});

//controller 
const createManager = async (req, res) => {
    const adminid = req.user.id;
    if (!adminid) {
        return res.status(401).json({ message: "Token is not provided" });
    }
    const existingUser = await manager.findOne({ email: req.body.email });
    if (existingUser) {
        return res.status(400).json({ message: "User already register....in database" });
    }
    try {
        const { error, value } = managerschemas.validate({ ...req.body, admin_id: adminid });
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const newManagerInstance = new manager(value);
        const newmanager = await newManagerInstance.save();
        if (!newmanager) {
            return res.status(404).json({ message: "Manager creation failed" });
        }
        // const token = generateToken(createManager, 'manager')
        //send mail services
        const subject = 'Welcome to the Manager Panel';
        const email = req.body.email;
        const text = `Hello,\n\n Congratulations! Your manager account has been created.
      \n\nEmail: ${email}\n\n You can now log in to the manager panel using the provided password within the next 10 minutes.
      \n\nBest regards,\nThe admin Team \n\n http://localhost:3000/api/v1/restaurant/password/:id`;

        const emailSent = await mailService.sendEmail(email, subject, text);
        if (emailSent) {
            const ipaddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
            console.log(ipaddress)
            return res.status(200).json({ message: "mail send ok!!!", newmanager })
        } else {
            await newManagerInstance.delete();
            return res.status(401).json({ message: "unale to sent password created link" })
        }
    } catch (error) {
        console.error("Error", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

const updatepassword = async (req, res) => {
    const managerid = req.params.id;
    const password = req.body.password;
    if (!managerid || !password) {
        return res.status(400).json({ message: "manager or newpassword not filled" });
    }
    try {
        const updateManager = await manager.findByIdAndUpdate(managerid, { password: password }, { new: true });
        if (!updateManager) {
            return res.status(400).json({ message: "manager not found" })
        }
        const email = req.body.email;
        const subject = 'Password Updated Successfully';
        const text = `Hello,\n\n Your password has been updated successfully.\n\nBest regards,\nThe admin Team`;
        await mailService.sendEmail(email, subject, text);
        res.status(200).json({ message: "Password updated successfully", updateManager });
    } catch (error) {
        console.log("Error", error);
        res.status(500).json({ message: "internal server error" });
    }
}
const getallactivemanager = async (req, res) => {
    const restaurantId = req.params.restaurant_id;
    if (!restaurantId) {
        return res.status(400).json({ message: "there is no restarurant for this manager" });
    }
    try {
        const Manager = await manager.find({ restaurant_id: restaurantId, isActive: true })
        if (!Manager) {
            return res.status(400).json({ message: "manager not found" })
        }
        res.status(200).json({ message: Manager })
    } catch (error) {
        res.status(500).json({ message: "internal server error" });
    }
}
module.exports = {
    createManager,
    updatepassword,
    getallactivemanager,
}
