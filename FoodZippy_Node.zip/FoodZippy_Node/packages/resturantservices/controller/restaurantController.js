const Joi = require("joi");
const Restaurant = require("../../common/model/restaurantSchema");
const fs = require("fs");
const path = require("path");
const Admin = require("../../common/model/adminSchema");
const branchRestaurant = require("../../common/model/branchRestaurantschema")
const restaurantSchema = Joi.object({
  logoImage: Joi.object().keys({
    data: Joi.binary(),
    contentType: Joi.string(),
  }),
  imageURL: Joi.string(),
  restaurantName: Joi.string(),
  address: Joi.string(),
  currency: Joi.string(),
  city: Joi.string(),
  zipcode: Joi.string(),
  mobile: Joi.object({
    countryCode: Joi.string(),
    phoneNumber: Joi.string().length(10),
  }).optional(),
  facilities: Joi.string(),
  serviceDescription: Joi.string(),
  is_active: Joi.boolean().default(true),
  mapLocation: Joi.object({
    lat: Joi.number(),
    long: Joi.number(),
  }),
  admin_id: Joi.string(),
});
const createRestaurant = async (req, res) => {
  try {
    // Access other fields from the request body
    const {
      restaurantName,
      address,
      currency,
      city,
      zipcode,
      mobile,
      is_active,
      mapLocation,
    } = req.body;

    // Access the user_id from the token
    const admin_id = req.user;

    // Define a Joi schema for request body validation
    const { error: bodyValidationError, value: validatedBody } =
      restaurantSchema.validate({
        restaurantName,
        address,
        currency,
        city,
        zipcode,
        mobile,
        is_active,
        mapLocation,
        //admin_id,
      });

    // Check if there is a validation error in the request body
    if (bodyValidationError) {
      return res
        .status(400)
        .json({ error: bodyValidationError.details[0].message });
    }

    // Initialize a new Restaurant object with the validated data
    const newRestaurant = new Restaurant({
      restaurantName,
      address,
      currency,
      city,
      zipcode,
      mobile,
      is_active,
      mapLocation,
    });
    newRestaurant.admin_id = admin_id;
    // Check if a file was uploaded
    if (req.file) {
      newRestaurant.logoImage = {
        data: req.file.buffer,
        contentType: req.file.mimetype,
      };
    }
    const imageFileName = `${newRestaurant._id}_${Date.now()}.${req.file.originalname
      }`;
    const imagePath = `/uploads/${imageFileName}`; // Relative path to the image
    newRestaurant.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
    // Save the new restaurant to the database
    await newRestaurant.save();

    // Send a success response
    res.status(201).json({
      message: "Restaurant created successfully",
      restaurantDetails: newRestaurant,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
const updateRestaurant = async (req, res) => {
  try {
    const { restaurantId } = req.params; // Assuming the restaurant ID is passed as a parameter
    const admin_id = req.user;

    // Check if the restaurant with the provided ID exists
    const existingRestaurant = await Restaurant.findOne({
      _id: restaurantId,
      admin_id,
    });

    if (!existingRestaurant) {
      return res.status(404).json({ error: "Restaurant not found" });
    }

    // Access fields to be updated from the request body
    const {
      restaurantName,
      address,
      currency,
      city,
      zipcode,
      mobile,
      is_active,
      facilities,
      serviceDescription,
      mapLocation,
    } = req.body;

    // Update the existing restaurant object
    existingRestaurant.restaurantName = restaurantName;
    existingRestaurant.address = address;
    existingRestaurant.currency = currency;
    existingRestaurant.city = city;
    existingRestaurant.zipcode = zipcode;
    existingRestaurant.mobile = mobile;
    existingRestaurant.is_active = is_active;
    existingRestaurant.facilities = facilities;
    existingRestaurant.serviceDescription = serviceDescription;
    existingRestaurant.mapLocation = mapLocation;

    // Check if a file was uploaded for updating the logo image
    if (req.file) {
      existingRestaurant.logoImage = {
        data: req.file.buffer,
        contentType: req.file.mimetype,
      };
    }

    // Save the updated restaurant to the database
    await existingRestaurant.save();

    // Send a success response
    res.json({
      message: "Restaurant updated successfully",
      restaurantDetails: existingRestaurant,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
const getAllRestaurantsByAdminId = async (req, res) => {
  try {
    const admin_id = req.user._id; // Assuming you have the admin_id from the authenticated user
    // Find all restaurants that belong to the specified admin_id
    const restaurants = await Restaurant.find({ admin_id });

    // Check if any restaurants were found
    if (restaurants.length === 0) {
      return res
        .status(404)
        .json({ error: "No restaurants found for this admin_id" });
    }
    res.status(200).json({ message: restaurants })
    // Send the array of restaurant objects in the response
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
const basicinfo = async (req, res) => {
  const adminId = req.user.id;
  try {
    const admin = await Admin.findById(adminId);
    if (!admin) {
      res.status(404).json({ message: "admin not found" });
    }
    const resturent = await Restaurant.find({ admin_id: adminId });
    if (!resturent) {
      res.status(404).json({ message: "restaurant is not avilable" });
    }
    res
      .status(200)
      .json({ message: "information taken ok!!", admin, resturent });
  } catch (e) {
    console.log(e);
    res.status(500).json({ message: "internal server error" });
  }
};
// const getRestaurantById = async (req, res) => {
//   try {
//     const restaurantId = req.params.restaurantId;
//     // Fetch order by restaurantId
//     const order = await Restaurant.find({ _id: restaurantId });

//     if (!order) {
//       return res.status(404).json({ error: "Restaurant not found" });
//     }
//     res.status(200).json({ order });
//   } catch (error) {
//     console.error("Error fetching restaurant:", error);
//     res.status(500).json({ error: "Unable to fetch restaurant." });
//   }
// };
const getRestaurantById = async (req, res) => {
  try {
    const restaurantId = req.params.restaurantId;

    // Fetch restaurant by ID
    const restaurant = await Restaurant.findById(restaurantId);

    if (!restaurant) {
      return res.status(404).json({ error: "Restaurant not found" });
    }

    // Fetch branches of the restaurant
    const branches = await branchRestaurant.find({ restaurant_id: restaurantId });

    // Include branches in the restaurant response
    const restaurantWithBranches = {
      _id: restaurant._id,
      restaurantName: restaurant.restaurantName,
      logoImage: restaurant.logoImage,
      mapLocation: restaurant.mapLocation,
      address: restaurant.address,
      zipcode: restaurant.zipcode,
      imageURL: restaurant.imageURL,
      // mobile: restaurant.mobile.countryCode,
      // mobile: restaurant.mobile.phoneNumber,
    };

    res.status(200).json({ restaurant: restaurantWithBranches, branches });
  } catch (error) {
    console.error("Error fetching restaurant:", error);
    res.status(500).json({ error: "Unable to fetch restaurant." });
  }
};


module.exports = {
  createRestaurant,
  updateRestaurant,
  getAllRestaurantsByAdminId,
  basicinfo,
  getRestaurantById,
};
