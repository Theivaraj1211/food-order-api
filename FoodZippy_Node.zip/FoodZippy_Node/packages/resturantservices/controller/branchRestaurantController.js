const Joi = require("joi");
const branchRestaurant = require("../../common/model/branchRestaurantschema")
const branchRestaurantSchema = Joi.object({
    restaurant_id: Joi.string(),
    admin_id: Joi.string(),
    logoImage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }).allow(null), // Optional
    imageURL: Joi.string().allow(null), // Optional
    restaurantName: Joi.string().min(3).max(50),
    address: Joi.string().min(5).max(255),
    currency: Joi.string().length(3),
    city: Joi.string().min(2).max(50),
    zipcode: Joi.string().min(3).max(10),
    mobile: Joi.object({
        countryCode: Joi.string(),
        phoneNumber: Joi.string(),
    }),
    is_active: Joi.boolean(),
    mapLocation: Joi.object({
        lat: Joi.number().min(-90).max(90),
        long: Joi.number().min(-180).max(180),
    }),
    storetimezone: Joi.date().default(Date.now), // Optional
    serviceDescription: Joi.string().allow(null), // Optional
    facilities: Joi.string().allow(null), // Optional
    publishRestaurant: Joi.boolean().default(false),
});
const createbreachrestaurant = async (req, res) => {
    try {
        // Access other fields from the request body
        const {
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            restaurant_id,
        } = req.body;

        // Access the user_id from the token
        const admin_id = req.user;

        // Define a Joi schema for request body validation
        const { error: bodyValidationError, value: validatedBody } =
            branchRestaurantSchema.validate({
                restaurantName,
                address,
                currency,
                city,
                zipcode,
                mobile,
                is_active,
                mapLocation,
                restaurant_id,
            });

        // Check if there is a validation error in the request body
        if (bodyValidationError) {
            return res
                .status(400)
                .json({ error: bodyValidationError.details[0].message });
        }

        // Initialize a new Restaurant object with the validated data
        const newRestaurant = new branchRestaurant({
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            restaurant_id,
        });

        // Set the admin_id from the token
        newRestaurant.admin_id = admin_id;

        // Check if a file was uploaded
        if (req.file) {
            newRestaurant.logoImage = {
                data: req.file.buffer,
                contentType: req.file.mimetype,
            };

            // Set imageURL based on the uploaded file
            const imageFileName = `${newRestaurant._id}_${Date.now()}.${req.file.originalname}`;
            const imagePath = `/uploads/${imageFileName}`;
            newRestaurant.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
        }

        // Save the new restaurant to the database
        await newRestaurant.save();

        // Send a success response
        res.status(201).json({
            message: "Restaurant created successfully",
            restaurantDetails: newRestaurant,
        });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
}
const updateBranchRestaurant = async (req, res) => {
    try {
        const branchRestaurantId = req.params.id
        // Access other fields from the request body
        const {
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            restaurant_id,
        } = req.body;

        // Access the user_id from the token
        const admin_id = req.user;

        // Validate the request body
        const { error: bodyValidationError, value: validatedBody } =
            branchRestaurantSchema.validate({
                restaurantName,
                address,
                currency,
                city,
                zipcode,
                mobile,
                is_active,
                mapLocation,
                restaurant_id,
            });

        // Check if there is a validation error in the request body
        if (bodyValidationError) {
            return res
                .status(400)
                .json({ error: bodyValidationError.details[0].message });
        }

        // Find the existing restaurant by ID
        const existingRestaurant = await branchRestaurant.findById({ _id: branchRestaurantId });

        // Check if the restaurant with the given ID exists
        if (!existingRestaurant) {
            return res.status(404).json({ error: "Restaurant not found" });
        }
        // Update the restaurant fields
        existingRestaurant.restaurantName = restaurantName;
        existingRestaurant.address = address;
        existingRestaurant.currency = currency;
        existingRestaurant.city = city;
        existingRestaurant.zipcode = zipcode;
        existingRestaurant.mobile = mobile;
        existingRestaurant.is_active = is_active;
        existingRestaurant.mapLocation = mapLocation;
        existingRestaurant.restaurant_id = restaurant_id;

        // Check if a new file was uploaded
        if (req.file) {
            existingRestaurant.logoImage = {
                data: req.file.buffer,
                contentType: req.file.mimetype,
            };

            // Update imageURL based on the new uploaded file
            const imageFileName = `${existingRestaurant._id}_${Date.now()}.${req.file.originalname}`;
            const imagePath = `/uploads/${imageFileName}`;
            existingRestaurant.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
        }

        // Save the updated restaurant to the database
        await existingRestaurant.save();

        // Send a success response
        res.status(200).json({
            message: "Restaurant updated successfully",
            restaurantDetails: existingRestaurant,
        });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};
module.exports = {
    createbreachrestaurant,
    updateBranchRestaurant,
}