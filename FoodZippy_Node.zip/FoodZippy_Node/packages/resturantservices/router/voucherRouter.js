const express = require("express");
const router = express.Router();
const {
  createVoucherCode,
  getAllVouchers,
} = require("../controller/voucherController");
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
// Define routes
router.post("/", requireAdminAuth, createVoucherCode);
router.get("/", getAllVouchers);
module.exports = router;
