const express = require("express");
const router = express.Router();
const { createDeliveryperson, updateDeliveryPerson, getAllDeliveryPersonsByRestaurantId } = require("../controller/deliverypersonController");
const { requireAdminAuth } = require("../../userservices/middleware/vaildateAdminToken");
const upload = require('../../userservices/middleware/multerConfig');
// Define routes
router.post("/", requireAdminAuth, upload.fields([
    { name: 'profileImage', maxCount: 1 },
    { name: 'idProofImage', maxCount: 1 },
    { name: 'licenseImage', maxCount: 1 },
]), createDeliveryperson);
router.put("/:id", requireAdminAuth, updateDeliveryPerson);
router.get("/:restaurantId", getAllDeliveryPersonsByRestaurantId);
module.exports = router;