const express = require("express");
const router = express.Router();
const {
  createAddToCartItem,
  getallcartbyuserId,
  updateCart,
} = require("../controller/AddcartitemController");
const {
  requireUserAuth,
} = require("../../userservices/middleware/vaildateUserToken");
// Define routes
router.post("/", requireUserAuth, createAddToCartItem);
router.put("/:cart_id", requireUserAuth, updateCart);
router.get("/", requireUserAuth, getallcartbyuserId);
module.exports = router;
