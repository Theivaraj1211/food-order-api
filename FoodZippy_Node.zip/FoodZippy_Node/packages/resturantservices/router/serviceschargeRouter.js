const express = require('express');
const router = express.Router();
const { createOrUpdateServiceCharge } = require('../controller/serviceschargeController');
const { requireAdminAuth } = require('../../userservices/middleware/vaildateAdminToken');

// Route to create or update service charge settings
router.post('/', requireAdminAuth, createOrUpdateServiceCharge);

module.exports = router;
