const express = require('express');
const router = express.Router();
const { createFavoriteItem,
    getFavoriteItemsByUserId,
    updateFavoriteItem,
} = require('../controller/favoriteController');
const { requireUserAuth } = require('../../userservices/middleware/vaildateUserToken');
// Define routes
router.post('/', requireUserAuth, createFavoriteItem);
router.get('/', requireUserAuth, getFavoriteItemsByUserId);
router.put('/', requireUserAuth, updateFavoriteItem);
module.exports = router;