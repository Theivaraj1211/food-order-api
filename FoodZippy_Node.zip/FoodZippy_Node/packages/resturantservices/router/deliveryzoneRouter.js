const express = require("express");
const router = express.Router();
const {
    requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
const { setdeliveryzone, getalldeliveryzone } = require("../controller/deliveryzoneController");
router.post("/", requireAdminAuth, setdeliveryzone);
router.get("/:restaurant_id", getalldeliveryzone)
module.exports = router;