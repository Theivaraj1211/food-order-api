const express = require("express");
const router = express.Router();
const {
  createMenuItem,
  getMenuItemsByRestaurantId,
  getAllMenuItems,
  getallmenuwithUserLocation,
  getCategoryNamesByRestaurantId,
} = require("../controller/menuController");
const upload = require("../../userservices/middleware/multerConfig");
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
const {
  requireUserAuth,
} = require("../../userservices/middleware/vaildateUserToken");
// Define routes
router.post("/", requireAdminAuth, upload.single("itemImage"), createMenuItem);
router.get("/:id", getMenuItemsByRestaurantId);
//router.get('/', getAllMenuItems);
router.get("/", requireUserAuth, getallmenuwithUserLocation);
router.get("/categoryNames/:restaurantId", getCategoryNamesByRestaurantId);
router.get("/all/all", getAllMenuItems);
module.exports = router;
