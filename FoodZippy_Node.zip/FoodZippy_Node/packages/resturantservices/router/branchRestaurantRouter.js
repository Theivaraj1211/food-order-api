const express = require("express");
const router = express.Router();
const { createbreachrestaurant, updateBranchRestaurant } = require("../controller/branchRestaurantController");
const { requireAdminAuth } = require("../../userservices/middleware/vaildateAdminToken");
const upload = require("../../userservices/middleware/multerConfig");
// Define routes
router.post("/", requireAdminAuth, upload.single("logoImage"), createbreachrestaurant);
router.put("/:id", requireAdminAuth, upload.single("logoImage"), updateBranchRestaurant);
module.exports = router;