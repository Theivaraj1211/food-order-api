const express = require("express");
const router = express.Router();
const {
  createRestaurant,
  getAllRestaurantsByAdminId,
  basicinfo,
  updateRestaurant,
  getRestaurantById,
} = require("../controller/restaurantController");
//const { requireUserAuth } = require('../../userservices/middleware/vaildateAdminToken')
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
// const multer = require('multer');

// const storage = multer.memoryStorage(); // Use memory storage for uploading files
const upload = require("../../userservices/middleware/multerConfig");
const {
  getallvoucherrestaurantId,
} = require("../controller/voucherController");
// Define routes
//router.route('/').put(requireUserAuth,updateUserWithImage)
router.post(
  "/",
  requireAdminAuth,
  upload.single("logoImage"),
  createRestaurant
);
router.get("/", requireAdminAuth, getAllRestaurantsByAdminId);
router.get("/basic/information", requireAdminAuth, basicinfo);
router.put("/", requireAdminAuth, updateRestaurant);
router.get("/user/information/:restaurantId", getRestaurantById);
router.get("/:restaurantId", getallvoucherrestaurantId);
module.exports = router;
