const express = require('express');
const router = express.Router();
const { requireAdminAuth } = require('../middleware/vaildateAdminToken');

const {
  createAdmin,
  getAdminById,
  // getAllAdmins,
  updateAdmin,
  login,
  //  logout,
  // deleteAdmin,
  verifyOTP,
  requestPasswordReset,
  resetPassword,
  createPassword,
  auditlogs,
} = require('../controller/adminController');

// Define routes
router.post('/', createAdmin);
router.post('/login', login);
router.post('/otpverify', requireAdminAuth, verifyOTP);
router.put('/', requireAdminAuth, updateAdmin);
router.get('/:id', requireAdminAuth, getAdminById);
router.post('/createpassword', requireAdminAuth, createPassword)
//router.get('/', getAllAdmins);
// router.post('/logout', logout);
// router.delete('/:id', deleteAdmin);
router.post('/forgotpassword', requestPasswordReset);
router.post('/resetpassword', requireAdminAuth, resetPassword);
router.get('/auditlog/:restaurant_id', auditlogs)
module.exports = router;