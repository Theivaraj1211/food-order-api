// const multer = require('multer');
// const path = require('path');

// const storage = multer.diskStorage({
//   destination: 'uploads', // Set your destination folder
//   filename: (req, file, callback) => {
//     const extension = path.extname(file.originalname);
//     const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
//     callback(null, uniqueSuffix + extension);
//     // callback(null ,extension);
//   },
// });

//  const upload = multer({ storage: storage });
// module.exports = upload;
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: 'uploads', // Set your destination folder
  filename: (req, file, callback) => {
    const extension = path.extname(file.originalname);
    // const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const userId = req.user.id; // Retrieve the user's ID from your authentication middleware
    // const filename = `${userId}-${uniqueSuffix}${extension}`;
    const filename = `${userId}${extension}`;
    callback(null, filename);
  },
});

const upload = multer({ storage: storage });

module.exports = upload;




