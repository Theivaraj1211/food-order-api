const Admin = require('../../common/model/adminSchema');
const { verifyToken } = require('./authMiddleware');
const apiResponse = require('../middleware/apiResponse');
const requireAdminAuth = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
        return apiResponse.unauthorizedResponse(res,'Unauthorized. Token not provided.' )
    }

    const decodedUser = verifyToken(token);

    if (decodedUser) {
        try {
            const { id } = decodedUser;
            const admin = await Admin.findById(id);

            if (!admin) {
                return apiResponse.validationError(res,'Unauthorized. Admin not found.' )
            }

            req.user = admin;
            next();
        } catch (err) {
            return apiResponse.serverErrorResponse(res,err.message);
        }
    } else {
        return apiResponse.unauthorizedResponse(res, 'Unauthorized. Invalid token or token has expired.' );
    }
};

module.exports = {requireAdminAuth}
